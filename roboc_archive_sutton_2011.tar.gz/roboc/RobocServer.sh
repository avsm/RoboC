#!/bin/bash

/tmp/roboc/roboc/scop/scopserver --allhosts

echo export ROBONET=`hostname` > /ux/clteach/Courses/Sutton/set_robonet.sh
chmod +x /ux/clteach/Courses/Sutton/set_robonet.sh
